/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../DBC_Edit (4)/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtGui/qscreen.h>
#include <QtCharts/qlineseries.h>
#include <QtCharts/qabstractbarseries.h>
#include <QtCharts/qvbarmodelmapper.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCharts/qcandlestickseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qxyseries.h>
#include <QtCharts/qxyseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qboxplotseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qpieseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCharts/qxyseries.h>
#include <QtCore/qabstractitemmodel.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_bt_msg_clicked",
    "",
    "on_bt_del_lastline_clicked",
    "on_bt_signal_clicked",
    "on_bt_save_clicked",
    "on_bt_addDBC_clicked",
    "on_bt_OpenDBC_clicked",
    "on_sg_select_combo_currentIndexChanged",
    "index",
    "decodeCan",
    "_data",
    "dcodeMsgSg",
    "msg_id",
    "const char*",
    "sg_name",
    "colindex",
    "on_NewConnection",
    "on_ReadyRead",
    "on_sg_select_combo_2_currentIndexChanged",
    "on_bt_OpenDBC_2_clicked",
    "on_bt_OpenDBC_3_clicked",
    "on_sg_endian_2_activated"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[11];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[27];
    char stringdata4[21];
    char stringdata5[19];
    char stringdata6[21];
    char stringdata7[22];
    char stringdata8[39];
    char stringdata9[6];
    char stringdata10[10];
    char stringdata11[6];
    char stringdata12[11];
    char stringdata13[7];
    char stringdata14[12];
    char stringdata15[8];
    char stringdata16[9];
    char stringdata17[17];
    char stringdata18[13];
    char stringdata19[41];
    char stringdata20[24];
    char stringdata21[24];
    char stringdata22[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 17),  // "on_bt_msg_clicked"
        QT_MOC_LITERAL(29, 0),  // ""
        QT_MOC_LITERAL(30, 26),  // "on_bt_del_lastline_clicked"
        QT_MOC_LITERAL(57, 20),  // "on_bt_signal_clicked"
        QT_MOC_LITERAL(78, 18),  // "on_bt_save_clicked"
        QT_MOC_LITERAL(97, 20),  // "on_bt_addDBC_clicked"
        QT_MOC_LITERAL(118, 21),  // "on_bt_OpenDBC_clicked"
        QT_MOC_LITERAL(140, 38),  // "on_sg_select_combo_currentInd..."
        QT_MOC_LITERAL(179, 5),  // "index"
        QT_MOC_LITERAL(185, 9),  // "decodeCan"
        QT_MOC_LITERAL(195, 5),  // "_data"
        QT_MOC_LITERAL(201, 10),  // "dcodeMsgSg"
        QT_MOC_LITERAL(212, 6),  // "msg_id"
        QT_MOC_LITERAL(219, 11),  // "const char*"
        QT_MOC_LITERAL(231, 7),  // "sg_name"
        QT_MOC_LITERAL(239, 8),  // "colindex"
        QT_MOC_LITERAL(248, 16),  // "on_NewConnection"
        QT_MOC_LITERAL(265, 12),  // "on_ReadyRead"
        QT_MOC_LITERAL(278, 40),  // "on_sg_select_combo_2_currentI..."
        QT_MOC_LITERAL(319, 23),  // "on_bt_OpenDBC_2_clicked"
        QT_MOC_LITERAL(343, 23),  // "on_bt_OpenDBC_3_clicked"
        QT_MOC_LITERAL(367, 24)   // "on_sg_endian_2_activated"
    },
    "MainWindow",
    "on_bt_msg_clicked",
    "",
    "on_bt_del_lastline_clicked",
    "on_bt_signal_clicked",
    "on_bt_save_clicked",
    "on_bt_addDBC_clicked",
    "on_bt_OpenDBC_clicked",
    "on_sg_select_combo_currentIndexChanged",
    "index",
    "decodeCan",
    "_data",
    "dcodeMsgSg",
    "msg_id",
    "const char*",
    "sg_name",
    "colindex",
    "on_NewConnection",
    "on_ReadyRead",
    "on_sg_select_combo_2_currentIndexChanged",
    "on_bt_OpenDBC_2_clicked",
    "on_bt_OpenDBC_3_clicked",
    "on_sg_endian_2_activated"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x08,    1 /* Private */,
       3,    0,  105,    2, 0x08,    2 /* Private */,
       4,    0,  106,    2, 0x08,    3 /* Private */,
       5,    0,  107,    2, 0x08,    4 /* Private */,
       6,    0,  108,    2, 0x08,    5 /* Private */,
       7,    0,  109,    2, 0x08,    6 /* Private */,
       8,    1,  110,    2, 0x08,    7 /* Private */,
      10,    1,  113,    2, 0x08,    9 /* Private */,
      12,    4,  116,    2, 0x08,   11 /* Private */,
      17,    0,  125,    2, 0x08,   16 /* Private */,
      18,    0,  126,    2, 0x08,   17 /* Private */,
      19,    1,  127,    2, 0x08,   18 /* Private */,
      20,    0,  130,    2, 0x08,   20 /* Private */,
      21,    0,  131,    2, 0x08,   21 /* Private */,
      22,    1,  132,    2, 0x08,   22 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::QString,   11,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 14, QMetaType::QString, QMetaType::Int,   13,   15,   11,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_bt_msg_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bt_del_lastline_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bt_signal_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bt_save_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bt_addDBC_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bt_OpenDBC_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sg_select_combo_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'decodeCan'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'dcodeMsgSg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<const char *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_NewConnection'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_ReadyRead'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sg_select_combo_2_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_bt_OpenDBC_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_bt_OpenDBC_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sg_endian_2_activated'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_bt_msg_clicked(); break;
        case 1: _t->on_bt_del_lastline_clicked(); break;
        case 2: _t->on_bt_signal_clicked(); break;
        case 3: _t->on_bt_save_clicked(); break;
        case 4: _t->on_bt_addDBC_clicked(); break;
        case 5: _t->on_bt_OpenDBC_clicked(); break;
        case 6: _t->on_sg_select_combo_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->decodeCan((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 8: _t->dcodeMsgSg((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<const char*>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[4]))); break;
        case 9: _t->on_NewConnection(); break;
        case 10: _t->on_ReadyRead(); break;
        case 11: _t->on_sg_select_combo_2_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->on_bt_OpenDBC_2_clicked(); break;
        case 13: _t->on_bt_OpenDBC_3_clicked(); break;
        case 14: _t->on_sg_endian_2_activated((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}
QT_WARNING_POP
